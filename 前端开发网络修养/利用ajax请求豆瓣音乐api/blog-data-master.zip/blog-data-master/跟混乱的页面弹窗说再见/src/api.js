import apiMock from './apiMock'

// 实际开发中，接口的数据定义和返回肯定是不一样的
// 这里只是为了更形象地模拟多个接口
export const api1 = name => apiMock(name)
export const api2 = name => apiMock(name)
export const api3 = name => apiMock(name)
export const api4 = name => apiMock(name)
export const api5 = name => apiMock(name)
export const api6 = name => apiMock(name)