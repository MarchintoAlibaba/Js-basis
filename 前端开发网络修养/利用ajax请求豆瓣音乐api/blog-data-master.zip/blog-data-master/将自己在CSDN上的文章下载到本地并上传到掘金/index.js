/**
 * 此为入口文件，定位到此文件所在目录，打开控制台，输入 `node index` 即可启动项目
 */
require('./src/getCSDNData.js')()