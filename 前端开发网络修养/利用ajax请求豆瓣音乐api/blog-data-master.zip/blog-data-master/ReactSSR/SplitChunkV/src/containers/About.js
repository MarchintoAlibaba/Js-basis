import React from 'react'

export default () => <h2>About</h2>