
进入 `Basic` 或 `SplitChunkV`目录（两个目录下都是完整的客户端代码，相互独立，`Basic`项目中是基本的 `SSR`项目，`SplitChunkV`是使用了代码分割的 `SSR`项目），启动客户端项目：
```js
npm run dev
```

然后访问 `http://127.0.0.1:3000`(端口号是 `koa server`端的端口号) 即可