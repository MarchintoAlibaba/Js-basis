import React from 'react'
import { render } from 'react-dom'

import Cart from './parabola'

render(
  <Cart/>,
  document.getElementById('root')
)
